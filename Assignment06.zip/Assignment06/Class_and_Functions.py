# -------------------------------------------------#
# Title: Working with Classes and Functions
# Dev:   Madhumita Acharya
# Date:  May 14, 2017
# ChangeLog: (Who, When, What)
#   MAcharya, 05/14/2017, Created.
# -------------------------------------------------#

# !/usr/bin/env python3

"""
Create a list of dictionaries with each dictionary containing the task and its priority. 
The program starts with a starter file that contains two rows of data to start with. 
These two rows of data are read from the file and put in two separate dictionaries. 
The key of the dictionary is the task and the value of the key is the priority of the task.  
These individual dictionaries are then to be collected together in a list forming a list of dictionaries.
Provide options to the user to enable them to modify the list. 
The final list is then stored in the initial starter file.

"""


class tasks:
    """Create a class containing the various tasks to be perfomed on the file"""
    def __init__(self):
        """Initialize the class."""
        print("You can create or modify your tasks and priority by choosing from the options")

    def file_to_list(self):
        """Read the contents of ToDo.txt file and load them as a list of dictionaries."""
        inputfile = open("Todo.txt", "r")  # read the input file containing the initial entries.
        mylist = []  # initialize a list
        dictRow = {}
        strData = ""

        for row in inputfile:  # create list of dictionaries from the rows of the ToDo.txt file.
            strData = row.strip().split(",")  # create the key value pair for the dictionary from the file contents.
            print(strData)
            dictRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            mylist.append(dictRow)  # append to the list.

        inputfile.close()  # close the input file.
        return mylist

    def display_choices(self):
        """Display menu of options to the user to enable them to choose 
           what they want to do with the contents of the file
        """
        print("#########################################")
        print("You can add or remove items from the list")
        print("Choose from the following menu of options")
        print("#########################################")

        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)

        userChoice = input("What would you like to do? Enter an option number: ")

        return userChoice

    def display_list(self,filelist):
        """ Display the current list"""
        print("Your present list is:\n")
        for row in filelist:
            print(row["Task"] + "(" + row["Priority"] + ")")

    def add_task(self,filelist):
        """Add a new task and its priority to the list."""
        newtask = input("Enter the new task to be added to the list: ").strip()
        newpriority = input("Enter the priority of the new task (high or low): ").strip().lower()
        dictrow = {"Task": newtask, "Priority":newpriority}
        filelist.append(dictrow)

        print("The new task has been added to the list")
        return filelist

    def remove_task(self, filelist):
        """Remove a task and its priority from the list."""
        removeEntry = input("Enter the name of the task to remove: ").strip()
        i = 0  # Counter to make sure user makes a valid entry.
        pos = 0
        print(filelist)
        while pos < int(len(filelist)):
            if filelist[pos]["Task"] == removeEntry:
                del filelist[pos]
                print("Deleted task ", removeEntry)
                i += 1
            pos += 1

        if i == 0:
            print("\nEntered Task Does not exist in the List.\n")

        return filelist

    def save_to_file(self, filelist):
        """Save the changes made to the new list to the ToDO.txt file 
           if the user decides to do so.
        """
        writeFile = open("ToDo.txt","w")
        askUser = input("Do you want to save this data to file? (y/n): ").strip()
        if askUser.lower() == "y":
            for item in filelist:
                saveTask = item["Task"]
                savePriority = item["Priority"]
                writeFile.write("%s,%s\n" % (saveTask,savePriority))

        writeFile.close()
        return filelist

# The program execution starts with defining an object t1 of the class tasks type and
# then using a while loop to call the various functions based on the menu of options selected by the user.
t1 = tasks()
newlist = t1.file_to_list()

while True:
    option = t1.display_choices()
    if option.strip() == "1":
        t1.display_list(newlist)
    elif option.strip() == "2":
        filelist = t1.add_task(newlist)
        t1.display_list(filelist)
    elif option.strip() == "3":
        filelist = t1.remove_task(newlist)
        t1.display_list(filelist)
    elif option.strip() == "4":
        filelist = t1.save_to_file(newlist)
        t1.display_list(filelist)
    elif option.strip() == "5":
        filelist = t1.save_to_file(newlist)
        t1.display_list(filelist)
        break
