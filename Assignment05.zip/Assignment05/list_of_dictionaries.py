#!/usr/bin/env python3

"""
Create a list of dictionaries with each dictionary containing the task and its priority. 
The program starts with a starter file that contains two rows of data to start with. 
These two rows of data are read from the file and put in two separate dictionaries. 
The key of the dictionary is the task and the value of the key is the priority of the task.  
These individual dictionaries are then to be collected together in a list forming a list of dictionaries.
Provide options to the user to enable them to modify the list. 
The final list is then stored in the initial starter file.

"""

def mydict():
    """
    Create dictionaries out of the entruws in the ToDo.txt file.
    Store the dictionaries in a list.
    Provide a choice of options to the user to enable them to modify the list.
    Finally save the list in the ToDo.txt file.

    """
    inputfile = open("Todo.txt","r") # read the input file containing the initial entries.
    mydict = {} # initialize a dictionary
    mylist = [] # initialize a list
    row = 0

    for row in inputfile: # create list of dictionaries from the rows of the ToDo.txt file.
        mydict = {}
        (key,value) = row.strip().split(",") # create the key value pair for the dictionary from the file contents.
        mydict[key] = value.strip() # remove extra characters.
        mylist.append(mydict) # append to the list.

    inputfile.close() # close the input file.

    while True:
        print("#########################################")
        print("You can add or remove items from the list")
        print("Choose from the following menu of options")
        print("#########################################")

        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)

        userChoice = input("What would you like to do? Enter an option number: ")

        if userChoice == "1": # Show current data of the list.
            print("Your present list:\n", mylist)

        elif userChoice == "2": # Adds a new task to the list.
            newtask = input("Enter the new task to be added to the list: ")
            key = newtask.title().strip()

            for item in mylist: # Check if the new task entered already exists.
                if key in item:
                    print("Task already exists")
                    continue

            newpriority = input("Enter the priority of the new task (High or Low): ")
            value = newpriority.lower().strip()

            mydict = {}
            mydict[key] = value.strip() # Assign the value to the key in the dictionary for the new task.
            mylist.append(mydict) # Append the new dictionary to the list.
            print("The new task has been added to the list")

        elif userChoice == "3": # Remove a task from the list.
            removeEntry = input("Enter the name of the task to remove: ")
            i = 0 # Counter to make sure user makes a valid entry.
            for item in mylist:
                if removeEntry in item:
                    del item[removeEntry]
                    print("Deleted ",removeEntry)
                    i += 1
            if i == 0:
                print("\nEntered Task Does not exist in the List.\n")

        elif userChoice == "4": # Save to the file.
            print("Saving to File...")
            write_list_to_file(mylist, "ToDo.txt")
            print("Saved to File")

        elif userChoice == "5": # Exit the program after saving the list to the file.
            print("Saving the data to ToDo.txt file before exiting...")
            write_list_to_file(mylist, "ToDo.txt")
            print("Exiting Now")
            break


def write_list_to_file(list_name, filename):
    """
    Read the individual dictionaries in the list of dictionaries and 
    write the key, value pairs of the dictionary into a file.
    :param list_name: name of the list of dictionaries. Type: list object
    :param filename: name of th output file. Type: string
    :return: no returns
    
    """
    task_list = list_name

    myFile = open("ToDo.txt", "w")
    for item in task_list:  # Read the individual dictionaries and store the contents as comma separated values.
        for key, value in item.items():
            myFile.write("%s,%s\n" % (key, value))
    myFile.close()

if __name__ == "__main__":
    mydict()